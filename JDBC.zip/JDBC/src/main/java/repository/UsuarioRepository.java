package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import db.Conexion;
import model.Usuario;

public class UsuarioRepository {
    
    public void insertarUsuario(Usuario usuario) {
        String sql = "INSERT INTO USUARIO (NOMBRE, EDAD) VALUES (?, ?)";

        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, usuario.getNombre());
            preparedStatement.setLong(2, usuario.getEdad());

            preparedStatement.executeUpdate();

            System.out.println("Usuario insertado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Usuario> listarUsuarios() {
        ArrayList<Usuario> listaUsuarios = new ArrayList<>();
        String sql = "SELECT * FROM USUARIO";

        try (Connection connection = Conexion.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
                

            while (resultSet.next()) {
                Usuario usuario = new Usuario(null,null,null);
                usuario.setId(resultSet.getLong("ID"));
                usuario.setNombre(resultSet.getString("NOMBRE"));
                usuario.setEdad(resultSet.getLong("EDAD"));

                listaUsuarios.add(usuario);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaUsuarios;
    }    

    public void actualizarUsuario(Long id, String nuevoNombre, Long nuevaEdad) {
        String sql = "UPDATE USUARIO SET NOMBRE = ?, EDAD = ? WHERE ID = ?";
        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setLong(3, id);
            preparedStatement.setString(1, nuevoNombre);
            preparedStatement.setLong(2, nuevaEdad);

            int filas = preparedStatement.executeUpdate();
            if (filas > 0) {
                System.out.println("Usuario actualizado correctamente");
            } else {
                System.out.println("No se encontró un usuario con ese ID");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void eliminarUsuario(Long id) {
        String sql = "DELETE FROM USUARIO WHERE ID = ?";
        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setLong(1, id);

            int filas = preparedStatement.executeUpdate();
            if (filas > 0) {
                System.out.println("Se eliminó al usuario");
            } else {
                System.out.println("No se encontró el usuario");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Usuario obtenerUsuarioPorId(Long id) {
    Usuario usuario = null;
    String sql = "SELECT * FROM USUARIO WHERE ID = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedstatement = connection.prepareStatement(sql)) {

        preparedstatement.setLong(1, id);
        ResultSet resultSet = preparedstatement.executeQuery();

        if (resultSet.next()) {
            usuario = new Usuario(null,null,null);
            usuario.setId(resultSet.getLong("ID"));
            usuario.setNombre(resultSet.getString("NOMBRE"));
            usuario.setEdad(resultSet.getLong("EDAD"));
        }

        resultSet.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return usuario;
    }

    public Usuario obtenerUsuarioPorNombre(String nombre) {
    Usuario usuario = null;
    String sql = "SELECT * FROM USUARIO WHERE NOMBRE = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedstatement = connection.prepareStatement(sql)) {

        preparedstatement.setString(1, nombre);
        ResultSet resultSet = preparedstatement.executeQuery();

        if (resultSet.next()) {
            usuario = new Usuario(null,null,null);
            usuario.setId(resultSet.getLong("ID"));
            usuario.setNombre(resultSet.getString("NOMBRE"));
            usuario.setEdad(resultSet.getLong("EDAD"));
        }

        resultSet.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return usuario;
    }
}

