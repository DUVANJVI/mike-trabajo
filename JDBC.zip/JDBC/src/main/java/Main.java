import java.util.ArrayList;
import java.util.Scanner;

import model.Usuario;
import repository.UsuarioRepository;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioRepository repo = new UsuarioRepository();
        int opcion;

        do {
            System.out.println("\n===== MENÚ DE USUARIOS =====");
            System.out.println("1. Insertar usuario");
            System.out.println("2. Listar usuarios");
            System.out.println("3. Actualizar usuario");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Buscar usuario por ID");
            System.out.println("6. Buscar usuario por nombre");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese nombre: ");
                    String nombre = scanner.nextLine();

                    System.out.print("Ingrese edad: ");
                    Long edad = scanner.nextLong();

                    repo.insertarUsuario(new Usuario(nombre, edad));
                    break;

                case 2:
                    ArrayList<Usuario> lista = repo.listarUsuarios();
                    System.out.println("\nUsuarios en sistema:");
                    for (Usuario u : lista) {
                        System.out.println(u.getId() + " - " + u.getNombre() + " - " + u.getEdad());
                    }
                    break;

                case 3:
                    System.out.print("Ingrese ID del usuario a actualizar: ");
                    Long idActualizar = scanner.nextLong();
                    scanner.nextLine();

                    System.out.print("Ingrese nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();

                    System.out.print("Ingrese nueva edad: ");
                    Long nuevaEdad = scanner.nextLong();

                    repo.actualizarUsuario(idActualizar, nuevoNombre, nuevaEdad);
                    break;

                case 4:
                    System.out.print("Ingrese ID del usuario a eliminar: ");
                    Long idEliminar = scanner.nextLong();
                    repo.eliminarUsuario(idEliminar);
                    break;

                case 5:
                    System.out.print("Ingrese el ID del usuario: ");
                    Long idBuscar = scanner.nextLong();
                    Usuario usuarioPorId = repo.obtenerUsuarioPorId(idBuscar);

                    if (usuarioPorId != null) {
                        System.out.println("\nUsuario encontrado:");
                        System.out.println("Id: " + usuarioPorId.getId());
                        System.out.println("Nombre: " + usuarioPorId.getNombre());
                        System.out.println("Edad: " + usuarioPorId.getEdad());
                    } else {
                        System.out.println("No existe un usuario con el id ingresado");
                    }
                    break;

                case 6:
                    System.out.print("Ingrese el nombre del usuario: ");
                    String nombreBuscar = scanner.nextLine();
                    Usuario usuarioPorNombre = repo.obtenerUsuarioPorNombre(nombreBuscar);

                    if (usuarioPorNombre != null) {
                        System.out.println("\n encontrado:");
                        System.out.println("Id: " + usuarioPorNombre.getId());
                        System.out.println("Nombre: " + usuarioPorNombre.getNombre());
                        System.out.println("Edad: " + usuarioPorNombre.getEdad());
                    } else {
                        System.out.println("No existe un Usuario con el nombre ingresado");
                    }
                    break;

                case 0:
                    System.out.println("Ah bueno, chao entonces 👍");
                    break;

                default:
                    System.out.println("Que del 0 al 6 le dije, no se haga el bobo y escriba lo que es pues 😒 \n");
            }

        } while (opcion != 0);

        scanner.close();
    }
}
